var searchData=
[
  ['node_7',['Node',['../class_node.html',1,'Node&lt; DATO &gt;'],['../class_node.html#a5d5390fb31933048a6b265371f8eb1c4',1,'Node::Node()'],['../class_node.html#aba074d436b22b1b6ba2f4fba4a819719',1,'Node::Node(DATO _data)'],['../class_node.html#a56865a0af02848d2f99a0ebcdecb8d0d',1,'Node::Node(DATO _data, Node&lt; DATO &gt; *_next)']]],
  ['node_2eh_8',['Node.h',['../_node_8h.html',1,'']]]
];

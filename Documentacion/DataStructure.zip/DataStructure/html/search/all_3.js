var searchData=
[
  ['linkedlist_4',['LinkedList',['../class_linked_list.html',1,'LinkedList&lt; DATO &gt;'],['../class_linked_list.html#a0983a0356a616f7fb72863207420ac39',1,'LinkedList::LinkedList()']]],
  ['linkedlist_2eh_5',['LinkedList.h',['../_linked_list_8h.html',1,'']]]
];

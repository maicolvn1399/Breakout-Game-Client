var searchData=
[
  ['eliminar_16',['eliminar',['../class_linked_list.html#a8319a8c7cf850c91e9cbd87cc7fd74d1',1,'LinkedList']]],
  ['estavacia_17',['estaVacia',['../class_linked_list.html#a2fc03a3c7ad2edc0f156375b57941e84',1,'LinkedList']]]
];

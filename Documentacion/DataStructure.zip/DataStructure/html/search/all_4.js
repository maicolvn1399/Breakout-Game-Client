var searchData=
[
  ['modify_6',['modify',['../class_node.html#a659dfd6814da37890793f892c7b2dd28',1,'Node']]]
];

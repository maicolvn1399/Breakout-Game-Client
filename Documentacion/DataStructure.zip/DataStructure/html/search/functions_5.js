var searchData=
[
  ['node_21',['Node',['../class_node.html#a5d5390fb31933048a6b265371f8eb1c4',1,'Node::Node()'],['../class_node.html#aba074d436b22b1b6ba2f4fba4a819719',1,'Node::Node(DATO _data)'],['../class_node.html#a56865a0af02848d2f99a0ebcdecb8d0d',1,'Node::Node(DATO _data, Node&lt; DATO &gt; *_next)']]]
];

var searchData=
[
  ['decreasesize_48',['decreaseSize',['../class_game_bar.html#ad2a88d87eacaa980abb676e46fbddc97',1,'GameBar']]],
  ['decreasevelocity_49',['decreaseVelocity',['../class_game_ball.html#ac49de274f8675cc1e53c96b2d46d3832',1,'GameBall']]]
];

var searchData=
[
  ['increasesize_22',['increaseSize',['../class_game_bar.html#a0c7a77014a452c81d3f4b244bd374be4',1,'GameBar']]],
  ['increasevelocity_23',['increaseVelocity',['../class_game_ball.html#a445375d246aa667f3b4070132f11fa30',1,'GameBall']]]
];

var searchData=
[
  ['selectsurprise_68',['selectSurprise',['../class_game_breakout.html#ac887e4e9797be558339c91f34b4ff9b7',1,'GameBreakout']]],
  ['setblockcolors_69',['setBlockColors',['../class_game_block.html#ad1b411bd2a6232ce1a6a901d258814a0',1,'GameBlock']]],
  ['setblockspositions_70',['setBlocksPositions',['../class_game_block.html#a7972641d364346aa950014af26bd7de2',1,'GameBlock']]],
  ['setblocktypes_71',['setBlockTypes',['../class_game_block.html#a99cc0ef16aef65ef7fed25fd3f6110b2',1,'GameBlock']]],
  ['setfalsevaluestoarray_72',['setFalseValuesToArray',['../class_game_block.html#a7bb1fa8023e4ed62726758e20d2a47f9',1,'GameBlock']]],
  ['setposition_73',['setPosition',['../class_game_ball.html#a316744fa044368ff2bc25cdd23ffe2af',1,'GameBall']]]
];

var searchData=
[
  ['movefaster_24',['moveFaster',['../class_game_ball.html#abd796684400867d0c4e0b4831209a549',1,'GameBall']]]
];

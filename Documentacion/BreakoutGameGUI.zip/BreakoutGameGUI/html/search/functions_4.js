var searchData=
[
  ['gameball_51',['GameBall',['../class_game_ball.html#a94e26ea9652e3a402090cb1f4a5b3653',1,'GameBall']]],
  ['gamebar_52',['GameBar',['../class_game_bar.html#a68f985450dc29665e16b3beeb60ef7d4',1,'GameBar']]],
  ['gameblock_53',['GameBlock',['../class_game_block.html#a075044fe899916b2725951ed2b55718f',1,'GameBlock']]],
  ['gamebreakout_54',['GameBreakout',['../class_game_breakout.html#a16690b495e73738737abf8c27f12899d',1,'GameBreakout']]],
  ['getangle_55',['getAngle',['../class_game_ball.html#af44884f39be08fee8b336268649b3cf4',1,'GameBall']]],
  ['getball_56',['getBall',['../class_game_ball.html#a73b69d5fdfe8f8c8653cc985a902ce9a',1,'GameBall']]],
  ['getbar_57',['getBar',['../class_game_bar.html#a1e48641e938d0a182947019713d54ef9',1,'GameBar']]],
  ['getblock_58',['getBlock',['../class_game_block.html#a1de6a264806a73319368fe9f3948b671',1,'GameBlock']]],
  ['getdefaultspeed_59',['getDefaultSpeed',['../class_game_ball.html#addbd75c020c4e1e74976805747f357fc',1,'GameBall']]],
  ['getisblock_60',['getIsBlock',['../class_game_block.html#a0a1132a6eb5ec0647788a83488aa220d',1,'GameBlock']]],
  ['getspeed_61',['getSpeed',['../class_game_ball.html#aeea8bf9d7b0e07148ce00c89c1f6522f',1,'GameBall']]]
];

var searchData=
[
  ['addnewball_0',['addNewBall',['../class_game_breakout.html#ae30d720803f9b2426398a993ef933983',1,'GameBreakout']]],
  ['anglemovement_1',['angleMovement',['../class_game_ball.html#abbc0f6a2e41808b543c14aebf99e945d',1,'GameBall']]]
];

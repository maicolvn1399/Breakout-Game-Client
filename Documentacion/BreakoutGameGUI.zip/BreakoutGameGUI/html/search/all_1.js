var searchData=
[
  ['barmove_2',['barMove',['../class_game_bar.html#a0fb648d84457f0d0de9e8f9dea4a884e',1,'GameBar']]],
  ['boundariescollision_3',['boundariesCollision',['../class_game_ball.html#aaf5581c4bcb582d3f5099a186825575f',1,'GameBall']]]
];
